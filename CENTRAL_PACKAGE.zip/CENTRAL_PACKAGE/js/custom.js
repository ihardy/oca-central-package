(function(){
"use strict";
'use strict';

/************************************* BEGIN Bootstrap Script ************************************/

/* We are a CENTRAL_PACKAGE, so use the below line to bootstrap the module */

var centralApp = angular.module('centralCustom', ['angularLoad']);

// var app = angular.module('viewCustom', ['angularLoad']);

/************************************* END Bootstrap Script ************************************/

function insertActions(actions) {
    app.service('customActionService', function () {
        return {
            actions: [],
            processCustomAction: function processCustomAction(prmActionCtrl, action) {
                action.slug = action.name.replace(/\s+/g, ''); // remove whitespace
                action.iconname = action.slug.toLowerCase();
                action.index = Object.keys(prmActionCtrl.actionListService.actionsToIndex).length - 1; // ignore "none" and RISPushTo
                this.actions.push(action);
                return action;
            },
            setCustomAction: function setCustomAction(prmActionCtrl, action) {
                prmActionCtrl.actionLabelNamesMap[action.slug] = action.name;
                prmActionCtrl.actionIconNamesMap[action.slug] = action.iconname;
                prmActionCtrl.actionIcons[action.iconname] = {
                    icon: action.icon.name,
                    iconSet: action.icon.set,
                    type: "svg"
                };
                if (!prmActionCtrl.actionListService.actionsToIndex[action.slug]) {
                    // ensure we aren't duplicating the entry
                    prmActionCtrl.actionListService.requiredActionsList[action.index] = action.slug;
                    prmActionCtrl.actionListService.actionsToDisplay.unshift(action.slug);
                    prmActionCtrl.actionListService.actionsToIndex[action.slug] = action.index;
                }
                if (action.type === 'template') {
                    if (action.hasOwnProperty('templateVar')) {
                        action.action = action.action.replace(/{\d}/g, function (r) {
                            return action.templateVar[r.replace(/[^\d]/g, '')];
                        });
                    }
                    action.action = action.action.replace(/{recordId}/g, function (r) {
                        return prmActionCtrl.item.pnx.search.recordid[0];
                    });
                }
                prmActionCtrl.onToggle[action.slug] = function () {
                    window.open(action.action, '_blank'); // opens the url in a new window
                };
            },
            setCustomActionContainer: function setCustomActionContainer(mdTabsCtrl, action) {// for further review...
            },
            getCustomActions: function getCustomActions() {
                return this.actions;
            }
        };
    }).component('prmActionListAfter', {
        require: {
            prmActionCtrl: '^prmActionList'
        },
        controller: 'customActionController'
    }).component('prmActionContainerAfter', {
        require: {
            mdTabsCtrl: '^mdTabs'
        },
        controller: 'customActionContainerController'
    }).controller('customActionController', ['$scope', 'customActionService', function ($scope, customActionService) {
        var vm = this;
        vm.$onInit = function () {
            console.log(vm.prmActionCtrl);
            actions.forEach(function (action) {
                var processedAction = customActionService.processCustomAction(vm.prmActionCtrl, action);
                customActionService.setCustomAction(vm.prmActionCtrl, processedAction);
            });
        };
    }]).controller('customActionContainerController', ['$scope', 'customActionService', function ($scope, customActionService) {
        var vm = this;
        vm.$onInit = function () {
            console.log(vm.mdTabsCtrl);
        };
    }]);
}

function addWorldcatButton(opts) {
    app.component('prmSearchResultListAfter', {
        require: {
            prmSearchCtrl: '^prmSearch'
        },
        controller: 'worldcatButtonController',
        template: '<md-card class="default-card _md zero-margin md-primoExplore-theme" ng-hide="getZeroResults()">\n            <md-card-title>' + opts.title + '</md-card-title>\n            <md-card-content>\n                <md-button class="md-raised" ng-click="searchWorldCat()">\n                <img src="https://cdn.rawgit.com/Alliance-PCJWG/primo-explore-worldcat-button/7ee112df/img/worldcat-logo.png" width="22" height="22" alt="worldcat-logo" style="vertical-align:middle;"> Search WorldCat\n                </md-button>\n            </md-card-content>\n        </md-card>'
    }).controller('worldcatButtonController', ['$scope', '$mdDialog', function ($scope, $mdDialog) {
        var vm = this;
        vm.$onInit = function () {
            $scope.wcBase = opts.link;
            $scope.$prmSearchCtrl = vm.prmSearchCtrl;
            $scope.getZeroResults = function () {
                if ($scope.$prmSearchCtrl.searchService.searchDone && $scope.$prmSearchCtrl.searchService.searchStateService.resultObject.info) {
                    $scope.searchTerm = $scope.$prmSearchCtrl.searchService.searchFieldsService.mainSearch;
                    return $scope.$prmSearchCtrl.searchService.searchStateService.resultObject.info.total !== 0;
                }
            };
            $scope.searchWorldCat = function () {
                window.open($scope.wcBase + "search?databaseList=&queryString=" + $scope.searchTerm, '_blank');
            };
        };
    }]);
}
})();